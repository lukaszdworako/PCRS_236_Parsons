# Relational algebra latex operators

PROJECT_OP = '\\pi'
RENAME_OP = '\\rho'
SELECT_OP = '\\sigma'
ASSIGN_OP = ':='

JOIN_OP = '\\times'
THETA_JOIN_OP = '\\times'
NATURAL_JOIN_OP = '\\bowtie'

DIFFERENCE_OP = '-'
UNION_OP = '\\cup'
INTERSECT_OP = '\\cap'