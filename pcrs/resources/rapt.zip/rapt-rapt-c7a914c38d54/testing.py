import rapt

translator = rapt.rapt.Rapt(grammar=rapt.treebrd.grammars.GRAMMARS['Extended Grammar'])
schema = {'ambiguous': ['a', 'a', 'b'], 'gammatwin': ['g1', 'g2'], 'beta': ['b1', 'b2', 'b3'], 'alphatwin': ['a1', 'a2', 'a3'], 'gammaprime': ['g1', 'g2'], 'alphaprime': ['a1', 'a4', 'a5'], 'gamma': ['g1', 'g2'], 'alpha': ['a1', 'a2', 'a3'], 'delta': ['d1', 'd2']}

out = translator.to_syntax_tree(instring="\\project_{a4} (\\project_{a1} ((\select_{a1 >50} alphaprime) \\theta_join_{alphaprime.a1=gamma.g1} gamma));", schema=schema)

# out = translator.to_syntax_tree(instring="((\\project_{a1} ((\select_{a1 >50} alphaprime)) \\theta_join_{alphaprime.a1=gamma.g1} gamma));", schema=schema)

# out = translator.to_syntax_tree(instring="((((\select_{a1 >50} alphaprime)) \\theta_join_{alphaprime.a1=gamma.g1} gamma));", schema=schema)

print(out)
