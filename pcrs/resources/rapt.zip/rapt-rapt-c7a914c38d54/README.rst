rapt
====

The Relational Algebra Parser and Translator.

rapt is a relational algebra parser and translator.