CREATE DATABASE rapt_test_db;
CREATE USER raptor WITH PASSWORD 'raptolicious';
GRANT ALL ON DATABASE rapt_test_db TO raptor;