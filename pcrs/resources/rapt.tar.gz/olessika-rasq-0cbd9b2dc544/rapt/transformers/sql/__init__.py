SET_SEMANTICS = 'set_semantics'
BAG_SEMANTICS = 'bag_semantics'