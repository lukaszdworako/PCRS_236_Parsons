from .rapt import Rapt

__version__ = '0.0.1'


def main():
    # """Entry point for the application script"""
    pass