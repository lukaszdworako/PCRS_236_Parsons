rapt
====

rapt is a relational algebra parser and translator.
